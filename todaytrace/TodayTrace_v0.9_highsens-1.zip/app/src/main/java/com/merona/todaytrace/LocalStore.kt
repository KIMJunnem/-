package com.merona.todaytrace

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object LocalStore {
    private const val PREF = "today_trace_store"
    private const val KEY_EVENTS = "events"
    private const val KEY_MEMOS = "memos"
    private const val KEY_RUNNING = "running"

    fun setRunning(context: Context, running: Boolean) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(KEY_RUNNING, running).apply()
    }

    fun isRunning(context: Context): Boolean =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(KEY_RUNNING, false)

    fun addTranscript(context: Context, text: String) {
        if (text.isBlank()) return
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(KEY_EVENTS, "[]"))
        val obj = JSONObject().apply {
            put("time", System.currentTimeMillis())
            put("text", text.trim())
        }
        arr.put(obj)
        trimOld(arr)
        prefs.edit().putString(KEY_EVENTS, arr.toString()).apply()
    }

    fun addMemo(context: Context, text: String) {
        if (text.isBlank()) return
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(KEY_MEMOS, "[]"))
        arr.put(JSONObject().apply {
            put("time", System.currentTimeMillis())
            put("text", text.trim())
        })
        trimOld(arr)
        prefs.edit().putString(KEY_MEMOS, arr.toString()).apply()
    }

    data class Entry(val time: Long, val text: String)

    fun todayTranscripts(context: Context): List<Entry> = readToday(context, KEY_EVENTS)
    fun todayMemos(context: Context): List<Entry> = readToday(context, KEY_MEMOS)

    private fun readToday(context: Context, key: String): List<Entry> {
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(key, "[]"))
        val today = SimpleDateFormat("yyyyMMdd", Locale.KOREA).format(Date())
        val out = mutableListOf<Entry>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val time = o.optLong("time")
            if (SimpleDateFormat("yyyyMMdd", Locale.KOREA).format(Date(time)) == today) {
                out += Entry(time, o.optString("text"))
            }
        }
        return out
    }

    private fun trimOld(arr: JSONArray) {
        while (arr.length() > 1500) arr.remove(0)
    }
}
