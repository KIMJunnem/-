package com.merona.todaytrace

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Process
import java.util.Calendar

object UsageAnalyzer {
    data class AppUse(val label: String, val millis: Long)

    fun hasPermission(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun today(context: Context): List<AppUse> {
        if (!hasPermission(context)) return emptyList()
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val manager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val stats = manager.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            calendar.timeInMillis,
            System.currentTimeMillis()
        )
        val pm = context.packageManager
        return stats
            .filter { it.totalTimeInForeground > 60_000 && it.packageName != context.packageName }
            .map { stat ->
                val label = try {
                    val info: ApplicationInfo = pm.getApplicationInfo(stat.packageName, 0)
                    pm.getApplicationLabel(info).toString()
                } catch (_: Exception) {
                    stat.packageName.substringAfterLast('.')
                }
                AppUse(label, stat.totalTimeInForeground)
            }
            .sortedByDescending { it.millis }
            .take(8)
    }

    fun prettyDuration(ms: Long): String {
        val minutes = ms / 60_000
        val h = minutes / 60
        val m = minutes % 60
        return when {
            h > 0 && m > 0 -> "${h}시간 ${m}분"
            h > 0 -> "${h}시간"
            else -> "${m}분"
        }
    }
}
